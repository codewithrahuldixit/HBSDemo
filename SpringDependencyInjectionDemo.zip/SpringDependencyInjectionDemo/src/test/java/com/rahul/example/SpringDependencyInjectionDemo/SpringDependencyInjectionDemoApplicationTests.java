package com.rahul.example.SpringDependencyInjectionDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDependencyInjectionDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
