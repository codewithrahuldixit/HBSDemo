package com.rahul.example.SpringDependencyInjectionDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDependencyInjectionDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDependencyInjectionDemoApplication.class, args);
	}

}
